<?php

return [
    'text' => [
        'more' => 'Просмотреть все результаты',
        'show_in_all_categories' => 'Поиск во всех категориях'
    ],
];