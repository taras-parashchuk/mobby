<?php

return [
    'text' => [
        'more' => 'Переглянути всі результати',
        'show_in_all_categories' => 'Пошук в усіх категоріях'
    ],
];