# CHANGELOG

## 0.4.0 - 2020-06-30

### Changed
- Allow guzzle v7

## 0.3.0 - 2015-08-15

* Updated to work with Guzzle 6 as a middleware.

